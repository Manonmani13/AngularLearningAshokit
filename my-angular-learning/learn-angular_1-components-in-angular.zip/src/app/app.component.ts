import {Component} from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    Hello world
  `,
  styles: `
    :host {
      color: red;
    }
  `,
})
export class AppComponent {}
